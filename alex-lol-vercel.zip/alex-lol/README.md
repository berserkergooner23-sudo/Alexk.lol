# Alex.lol

A responsive, dark-themed AI workspace built as a static site with a Vercel serverless API route.

## What's included

- Responsive desktop/mobile interface
- Sidebar, recent chat list, new conversation flow
- Prompt starter cards and model selector
- Browser-local conversation history
- Secure server-side AI proxy (`/api/chat`) — your API key is never sent to the browser

## Deploy to Vercel (free hosting tier)

1. Download and unzip `alex-lol-vercel.zip`.
2. Create a GitHub account if you don't already have one: https://github.com
3. Create a new **public or private** GitHub repository named `alex-lol`.
4. Upload the contents of this folder to the repository. Make sure `index.html`, `styles.css`, `app.js`, and the `api` folder are at the repository root.
5. Sign in at https://vercel.com using GitHub.
6. Choose **Add New → Project**, import the `alex-lol` repository, and deploy. Vercel should detect this as a static project with a serverless function.
7. In the Vercel project, open **Settings → Environment Variables**. Add:
   - Name: `OPENAI_API_KEY`
   - Value: your secret API key from https://platform.openai.com/api-keys
   - Apply it to Production (and Preview if desired).
8. Go to **Deployments** and redeploy the latest deployment so the function receives the new variable.
9. Open the `.vercel.app` URL shown in the project dashboard.

## AI usage and costs

The site can be hosted on Vercel's free tier, subject to Vercel's current plan limits. Live AI replies require an OpenAI API key and API usage is billed separately by the provider; ChatGPT subscriptions do not include API credits. Never put your API key in `app.js`, `index.html`, or any other browser-side file.

## Custom domain

You do not need to buy `alex.lol` to launch. Vercel gives you a `*.vercel.app` address. If you later purchase `alex.lol`, add it under **Project → Settings → Domains** and follow Vercel's DNS instructions.

## Local preview

You can preview the static UI by opening `index.html` in a browser. The `/api/chat` endpoint only works after deployment to Vercel (or with Vercel's local development tooling).
