export default async function handler(req, res) {
  const apiKey = process.env.OPENAI_API_KEY;
  if (req.method === "GET") return res.status(200).json({ configured: Boolean(apiKey) });
  if (req.method !== "POST") return res.status(405).json({ error: "Method not allowed." });
  if (!apiKey) return res.status(503).json({ error: "AI connection not configured." });

  try {
    const body = req.body || {};
    const messages = Array.isArray(body.messages) ? body.messages : [];
    if (!messages.length) return res.status(400).json({ error: "Please send a message." });
    const safeMessages = messages.slice(-20).map(m => ({
      role: m.role === "assistant" ? "assistant" : "user",
      content: String(m.content || "").slice(0, 12000)
    }));
    const model = body.model === "gpt-4.1" ? "gpt-4.1" : "gpt-4.1-mini";
    const upstream = await fetch("https://api.openai.com/v1/chat/completions", {
      method: "POST",
      headers: { "Authorization": `Bearer ${apiKey}`, "Content-Type": "application/json" },
      body: JSON.stringify({
        model,
        messages: [
          { role: "system", content: "You are Alex, a helpful, friendly assistant inside Alex.lol. Be clear, useful, and honest. Format answers with readable paragraphs and markdown when useful." },
          ...safeMessages
        ],
        temperature: 0.7
      })
    });
    const result = await upstream.json();
    if (!upstream.ok) {
      return res.status(upstream.status).json({ error: result.error?.message || "The AI provider returned an error." });
    }
    return res.status(200).json({ reply: result.choices?.[0]?.message?.content || "I couldn't generate a reply." });
  } catch (error) {
    return res.status(500).json({ error: "Server error while contacting the AI provider." });
  }
}