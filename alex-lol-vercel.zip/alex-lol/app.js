const $ = (s) => document.querySelector(s);
const welcomeView = $("#welcomeView"), chatView = $("#chatView"), messagesEl = $("#messages");
const input = $("#messageInput"), form = $("#chatForm"), sendButton = $("#sendButton");
const STORAGE_KEY = "alexlol_chats_v1";
let chats = loadChats(), activeId = null, busy = false;

function loadChats(){ try{return JSON.parse(localStorage.getItem(STORAGE_KEY)||"[]")}catch{return []} }
function saveChats(){ localStorage.setItem(STORAGE_KEY,JSON.stringify(chats)); renderHistory(); }
function currentChat(){ return chats.find(c=>c.id===activeId); }
function newChat(){ activeId=null; messagesEl.innerHTML=""; chatView.classList.add("hidden"); welcomeView.classList.remove("hidden"); $("#topTitle").textContent="New conversation"; renderHistory(); input.focus(); }
function renderHistory(){
  const list=$("#historyList"); list.innerHTML="";
  if(!chats.length){list.innerHTML='<div class="empty-history">Your conversations will appear here.</div>';return;}
  chats.slice().reverse().forEach(c=>{const b=document.createElement("button");b.className="history-item"+(c.id===activeId?" selected":"");b.textContent=c.title;b.title=c.title;b.onclick=()=>openChat(c.id);list.append(b)});
}
function openChat(id){const c=chats.find(x=>x.id===id);if(!c)return;activeId=id;welcomeView.classList.add("hidden");chatView.classList.remove("hidden");$("#topTitle").textContent=c.title;messagesEl.innerHTML="";c.messages.forEach(m=>appendMessage(m.role,m.content));renderHistory();chatView.scrollTop=chatView.scrollHeight;}
function appendMessage(role,content){
  const wrap=document.createElement("div");wrap.className="message "+(role==="user"?"user":"assistant");
  const av=document.createElement("div");av.className="message-avatar";av.textContent=role==="user"?"Y":"A";
  const body=document.createElement("div");body.className="message-body";body.textContent=content;
  wrap.append(av,body);messagesEl.append(wrap);chatView.scrollTop=chatView.scrollHeight;return body;
}
function toast(msg){const t=$("#toast");t.textContent=msg;t.classList.add("show");setTimeout(()=>t.classList.remove("show"),2600)}
function resizeInput(){input.style.height="auto";input.style.height=Math.min(input.scrollHeight,180)+"px"}
input.addEventListener("input",resizeInput);
function setBusy(v){busy=v;sendButton.disabled=v;sendButton.textContent=v?"…":"↑";}
async function sendMessage(text){
  text=text.trim();if(!text||busy)return;
  if(!activeId){activeId=crypto.randomUUID();chats.push({id:activeId,title:text.slice(0,42)+(text.length>42?"…":""),messages:[]});}
  const chat=currentChat();chat.messages.push({role:"user",content:text});saveChats();
  welcomeView.classList.add("hidden");chatView.classList.remove("hidden");$("#topTitle").textContent=chat.title;
  appendMessage("user",text);input.value="";resizeInput();setBusy(true);
  const pending=appendMessage("assistant","Thinking…");pending.classList.add("typing");
  try{
    const response=await fetch("/api/chat",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({messages:chat.messages,model:$("#modelSelect").value})});
    const data=await response.json();
    if(!response.ok)throw new Error(data.error||"The AI request failed.");
    const answer=data.reply||"I didn't receive a response. Please try again.";
    pending.classList.remove("typing");pending.textContent=answer;
    chat.messages.push({role:"assistant",content:answer});saveChats();
  }catch(err){
    pending.classList.remove("typing");
    const msg=err.message.includes("not configured")?"Alex.lol is ready, but its AI connection isn't configured yet. Add your OPENAI_API_KEY in Vercel → Project → Settings → Environment Variables, then redeploy.":err.message;
    pending.textContent=msg;toast("Couldn't get an AI response");
  }finally{setBusy(false);chatView.scrollTop=chatView.scrollHeight;}
}
form.addEventListener("submit",e=>{e.preventDefault();sendMessage(input.value)});
document.querySelectorAll(".prompt-card").forEach(b=>b.addEventListener("click",()=>sendMessage(b.dataset.prompt)));
$("#newChat").onclick=newChat;$("#homeLink").onclick=e=>{e.preventDefault();newChat()};
$("#historyLink").onclick=e=>{e.preventDefault();if(chats.length)openChat(chats[chats.length-1].id);else toast("No conversations yet")};
$("#clearHistory").onclick=()=>{if(confirm("Delete all conversations saved in this browser?")){chats=[];saveChats();newChat();}};
$("#openSidebar").onclick=()=>$("#sidebar").classList.add("open");$("#closeSidebar").onclick=()=>$("#sidebar").classList.remove("open");
function showSettings(){const d=$("#settingsDialog");d.showModal();fetch("/api/chat",{method:"GET"}).then(r=>r.json()).then(x=>$("#apiStatus").textContent=x.configured?"Connected":"Not connected").catch(()=>$("#apiStatus").textContent="Not connected")}
$("#settingsButton").onclick=showSettings;$("#settingsTop").onclick=showSettings;$("#closeSettings").onclick=()=>$("#settingsDialog").close();$("#doneSettings").onclick=()=>$("#settingsDialog").close();
document.addEventListener("keydown",e=>{if((e.metaKey||e.ctrlKey)&&e.key.toLowerCase()==="k"){e.preventDefault();newChat();}});
renderHistory();
